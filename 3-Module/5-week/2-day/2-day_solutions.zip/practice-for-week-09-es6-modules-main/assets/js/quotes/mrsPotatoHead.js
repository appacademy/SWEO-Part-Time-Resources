//!!ADD
// {
//!!END_ADD
//!!START SILENT
export default {
	//!!END
		"hello": "Hi, I'm Mrs. Potato Head! Pleasure to meet you.",
		"bye": "Bye, Sweet Potato!"
}

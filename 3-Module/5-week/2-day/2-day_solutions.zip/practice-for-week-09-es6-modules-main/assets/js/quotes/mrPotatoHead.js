//!!ADD
// const mrPotatoHeadQuotes = {
//!!END_ADD
//!!START SILENT
export const mrPotatoHeadQuotes = {
	//!!END
		"hello": "Hi, I'm Mr. Potato Head!",
		"bye": "Bye, it's been nice talking to you!"
}

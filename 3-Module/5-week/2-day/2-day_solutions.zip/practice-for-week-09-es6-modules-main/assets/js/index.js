//!!START SILENT
import Game from './game.js';

//!!END
window.onload = () => {
    const game = new Game();
    game.start();
};

import {initializePage} from './main.js'
import {initializeFunctionality} from './main.js'

document.addEventListener('DOMContentLoaded', e => {
    initializePage()
    initializeFunctionality()
})